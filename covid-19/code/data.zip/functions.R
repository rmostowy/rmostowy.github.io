
# COVID-19 transmission model
model <- function(t, x, parms) {
  with(as.list(c(parms, x)), {
    ifelse(t < (seed + control), beta <- R_0*gamma/popsize, beta <- kappa*R_0*gamma/popsize)
    dS <- - beta*S*I
    dE <- beta*S*I - sigma*E
    dI <- sigma*E - gamma*I
    dH <- epsilon1*gamma*I - omega1*H
    dV <- epsilon2*omega1*H - omega2*V
    dR <- (1 - epsilon1)*gamma*I + (1 - epsilon2)*omega1*H + (1 - epsilon3)*omega2*V
    dD <- epsilon3*omega2*V
    dC <- sigma*E
    der <- c(dS, dE, dI, dH, dV, dR, dD, dC)
    list(der)
  })
}

# pars <- c(seed = log(35), R_0 = log(2.2), sigma = 1/3.75, gamma = 1/3.75, omega1 = 1/8, omega2 = 1/8, epsilon1 = 0.05, epsilon2 = 0.5, epsilon3 = .5, control = 21, kappa = qlogis(0.1))

# Negative log-likelihood
nll <- function(seed, R_0, sigma, gamma, omega1, omega2, epsilon1, epsilon2, epsilon3, control, kappa) {
  pars <- c(seed = seed, R_0 = R_0, sigma = sigma, gamma = gamma, omega1 = omega1, omega2 = omega2, epsilon1 = epsilon1, epsilon2 = epsilon2, epsilon3 = epsilon3, control = control, kappa = kappa)
  pars <- trans(pars)
  times <- c(0, pars["seed"] + reported$date - min(reported$date))
  times <- c(times, max(times + 1))
  simulation <- as.data.frame(ode(inits, times, model, pars))
  simulation <- simulation[-1, ]
  ll <- sum(dpois(reported$inc.deaths, diff(simulation$D), log = TRUE))
  return(-ll)
}

# Parameter transformations
trans <- function(pars) {
  pars["seed"] <- exp(pars["seed"])
  pars["kappa"] <- plogis(pars["kappa"])
  return(pars)
}

decimalplaces <- function(x) {
  if ((x %% 1) != 0) {
    nchar(strsplit(sub('0+$', '', as.character(x)), ".", fixed=TRUE)[[1]][[2]])
  } else {
    return(0)
  }
}

estimate.ci95.seed <- function(best.fit, lower.bound = -1e06, upper.bound = 1e6){
  best.fit.ll <- as.numeric(logLik(best.fit))
  best.fit.parms <- trans(coef(best.fit))
  best.fit.seed <- best.fit.parms["seed"]
  epsilon <- 10^(-decimalplaces(signif(best.fit.seed, d = 2)))
  varied.value <- best.fit.seed
  this.pval <- 0
  while(this.pval < 0.975){
    varied.value <- varied.value - epsilon
    varied.value.log <- log(varied.value)
    this.fixed <- best.fit.parms[names(best.fit.parms) != "kappa"]
    this.fixed["seed"] <- varied.value.log
    this.free <- plogis(best.fit.parms[names(best.fit.parms) == "kappa"])
    this.fit <- mle2(nll, start = as.list(this.free), fixed = as.list(this.fixed), method = "Brent", lower = lower.bound, upper = upper.bound)
    this.fit.ll <- as.numeric(logLik(this.fit))
    this.pval <- pchisq(2 * (best.fit.ll - this.fit.ll), 1)
  }
  lower.bound.seed <- trans(coef(this.fit))["seed"]
  
  varied.value <- best.fit.seed
  this.pval <- 0
  while(this.pval < 0.975){
    varied.value <- varied.value + epsilon
    varied.value.log <- log(varied.value)
    this.fixed <- best.fit.parms[names(best.fit.parms) != "kappa"]
    this.fixed["seed"] <- varied.value.log
    this.free <- plogis(best.fit.parms[names(best.fit.parms) == "kappa"])
    this.fit <- mle2(nll, start = as.list(this.free), fixed = as.list(this.fixed), method = "Brent", lower = lower.bound, upper = upper.bound)
    this.fit.ll <- as.numeric(logLik(this.fit))
    this.pval <- pchisq(2 * (best.fit.ll - this.fit.ll), 1)
  }
  upper.bound.seed <- trans(coef(this.fit))["seed"]
  out <- c(lower.bound.seed, upper.bound.seed)
  names(out) <- c("seed.lower.ci", "seed.upper.ci")
}

# qlogis(0) = -Inf
estimate.ci95.kappa <- function(best.fit){
  best.fit.ll <- as.numeric(logLik(best.fit))
  best.fit.parms <- trans(coef(best.fit))
  best.fit.kappa <- best.fit.parms["kappa"]
  epsilon <- 1
  varied.value <- qlogis(best.fit.kappa)
  this.pval <- 0
  while(this.pval < 0.975){
    varied.value <- varied.value - epsilon
    this.fixed <- best.fit.parms[names(best.fit.parms) != "seed"]
    this.fixed["kappa"] <- varied.value
    this.free <- log(best.fit.parms[names(best.fit.parms) == "seed"])
    this.fit <- mle2(nll, start = as.list(this.free), fixed = as.list(this.fixed), method = "BFGS")
    this.fit.ll <- as.numeric(logLik(this.fit))
    this.pval <- pchisq(2 * (best.fit.ll - this.fit.ll), 1)
  }
  lower.bound.seed <- trans(coef(this.fit))["seed"]
  
  varied.value <- best.fit.seed
  this.pval <- 0
  while(this.pval < 0.975){
    varied.value <- varied.value + epsilon
    varied.value.log <- log(varied.value)
    this.fixed <- best.fit.parms[names(best.fit.parms) != "kappa"]
    this.fixed["seed"] <- varied.value.log
    this.free <- plogis(best.fit.parms[names(best.fit.parms) == "kappa"])
    this.fit <- mle2(nll, start = as.list(this.free), fixed = as.list(this.fixed), method = "Brent", lower = lower.bound, upper = upper.bound)
    this.fit.ll <- as.numeric(logLik(this.fit))
    this.pval <- pchisq(2 * (best.fit.ll - this.fit.ll), 1)
  }
  upper.bound.seed <- trans(coef(this.fit))["seed"]
  out <- c(lower.bound.seed, upper.bound.seed)
  names(out) <- c("seed.lower.ci", "seed.upper.ci")
}

date2polish <- function(date, return.only.month = FALSE){
  month.names <- 1:12
  test <- is.Date(date)
  out <- NULL
  if(test){
    get.day <- day(date)
    get.month <- month(date)
    out <- sprintf("%d/%.2d", get.day, month.names[get.month])
    if(return.only.month) out <- sprintf("%.2d", month.names[get.month])
  } else{
    cat("Must be in lubridate format! Returning NULL...")
  }
  return(out)
}


